

#include "stdafx.h"
#include <windows.h>
#include <winioctl.h>
#include <stdio.h>

#include "hdinfo.h"


//��WORD��������ֽ���Ϊlittle-endian�����˳��ַ�����β�Ŀո�
void ToLittleEndian(PUSHORT pWords, int nFirstIndex, int nLastIndex, char* pBuf)
{

	if(!pBuf){return;}

    int index;
    char* pDest = pBuf;
    for(index = nFirstIndex; index <= nLastIndex; ++index)
    {
        pDest[0] = pWords[index] >> 8;
        pDest[1] = pWords[index] & 0xFF;
        pDest += 2;
    }    
    *pDest = 0;
    
    //trim space at the endof string; 0x20: _T(' ')
    --pDest;
    while(*pDest == 0x20)
    {
        *pDest = 0;
        --pDest;
    }
}

//�˳��ַ�����ʼλ�õĿո�
void TrimStart(char* pBuf)
{
    if(*pBuf != 0x20)
        return;

    char* pDest = pBuf;
    char* pSrc = pBuf + 1;
    while(*pSrc == 0x20)
        ++pSrc;

    while(*pSrc)
    {
        *pDest = *pSrc;
        ++pDest;
        ++pSrc;
    }
    *pDest = 0;
}


char *ConvertToString (DWORD diskdata [256], int firstIndex, int lastIndex, char* buf)
{
    int index = 0;
    int position = 0;

    //  each integer has two characters stored in it backwards
    for (index = firstIndex; index <= lastIndex; index++)
    {
        //  get high byte for 1st character
        buf [position++] = (char) (diskdata [index] / 256);

        //  get low byte for 2nd character
        buf [position++] = (char) (diskdata [index] % 256);
    }

    //  end the string
    buf[position] = '\0';

    //  cut off the trailing blanks
    for (index = position - 1; index > 0 && isspace(buf [index]); index--)
        buf [index] = '\0';

    return buf;
}


//
// Model Number: 40 ASCII Chars
// SerialNumber: 20 ASCII Chars
//
BOOL GetPhysicDriveSerialNumber(char* pModelNo, char* pSerialNo, unsigned int driveIndex)
{
    //-1����Ϊ SENDCMDOUTPARAMS �Ľ�β�� BYTE bBuffer[1];
    BYTE IdentifyResult[sizeof(SENDCMDOUTPARAMS) + IDENTIFY_BUFFER_SIZE - 1];
    DWORD dwBytesReturned;
    GETVERSIONINPARAMS get_version;
    SENDCMDINPARAMS send_cmd = { 0 };

	char driveName [256];
    sprintf (driveName, "\\\\.\\PhysicalDrive%d", driveIndex);
    HANDLE hFile = CreateFileA(driveName, GENERIC_READ | GENERIC_WRITE,    
        FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if(hFile == INVALID_HANDLE_VALUE)
        return FALSE;

    //get version
    DeviceIoControl(hFile, SMART_GET_VERSION, NULL, 0,
        &get_version, sizeof(get_version), &dwBytesReturned, NULL);

    //identify device
    send_cmd.irDriveRegs.bCommandReg = (get_version.bIDEDeviceMap & 0x10)? ATAPI_ID_CMD : ID_CMD;
    DeviceIoControl(hFile, SMART_RCV_DRIVE_DATA, &send_cmd, sizeof(SENDCMDINPARAMS) - 1,
        IdentifyResult, sizeof(IdentifyResult), &dwBytesReturned, NULL);
    CloseHandle(hFile);

    //adjust the byte order
    PUSHORT pWords = (USHORT*)(((SENDCMDOUTPARAMS*)IdentifyResult)->bBuffer);

	//DWORD diskdata [256];
    //int ijk = 0;
	//for (ijk = 0; ijk < 256; ijk++){
	//	diskdata [ijk] = pWords [ijk];
	//}
    //ConvertToString (diskdata, 10, 19, pSerialNo);
    //ConvertToString (diskdata, 27, 46, pModelNo);
    //ConvertToString (diskdata, 23, 26, pRevisionNumber);                    

    ToLittleEndian(pWords, 27, 46, pModelNo);
    ToLittleEndian(pWords, 10, 19, pSerialNo);
	//ToLittleEndian(pWords, 23, 26, pRevisionNumber);
    return TRUE;
}
