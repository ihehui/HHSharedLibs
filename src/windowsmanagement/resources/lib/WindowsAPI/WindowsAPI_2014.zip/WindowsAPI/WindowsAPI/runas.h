#ifndef __RUNAS_H__
#define __RUNAS_H__


#include "lib.h"


#define WINSTA_ALL (WINSTA_ACCESSCLIPBOARD  | WINSTA_ACCESSGLOBALATOMS | \
	WINSTA_CREATEDESKTOP    | WINSTA_ENUMDESKTOPS      | \
	WINSTA_ENUMERATE        | WINSTA_EXITWINDOWS       | \
	WINSTA_READATTRIBUTES   | WINSTA_READSCREEN        | \
	WINSTA_WRITEATTRIBUTES  | DELETE                   | \
	READ_CONTROL            | WRITE_DAC                | \
	WRITE_OWNER)

#define DESKTOP_ALL (DESKTOP_CREATEMENU      | DESKTOP_CREATEWINDOW  | \
	DESKTOP_ENUMERATE       | DESKTOP_HOOKCONTROL   | \
	DESKTOP_JOURNALPLAYBACK | DESKTOP_JOURNALRECORD | \
	DESKTOP_READOBJECTS     | DESKTOP_SWITCHDESKTOP | \
	DESKTOP_WRITEOBJECTS    | DELETE                | \
	READ_CONTROL            | WRITE_DAC             | \
	WRITE_OWNER)

#define GENERIC_ACCESS (GENERIC_READ    | GENERIC_WRITE | \
	GENERIC_EXECUTE | GENERIC_ALL)



#ifdef __cplusplus
extern "C"
{
#endif


	// Functionality:
	//    Get User SessionID.
	// Parameters:
	//    0) [in] lpszUsername: User Name.
	//	  1) [in][out] pSessionID: User SessionID.
	// Returned value:
	//    true if user SessionID found, or false.
	WINDOWSAPI_API bool getUserSessionID(LPCWSTR lpszUserName, DWORD *pSessionID);

	// Functionality:
	//    Start a interactive process in another user's session. Only for NT6 and later system's service.
	//    The user must have been logged on.
	// Parameters:
	//    0) [in] dwSessionID: Session ID of target desktop to show the process window .
	//	  ...
	// Returned value:
	//    Error Code.
	WINDOWSAPI_API int runAsForNT6InteractiveService(DWORD dwSessionID, LPCWSTR lpApplicationName, LPWSTR lpCommandLine, LPCWSTR lpWorkingDir, bool bShowWindow);


	// Functionality:
	//    Start a interactive process in another user's session. Only for NT5 system's service.
	//    The user must have been logged on.
	// Parameters:
	//    0) [in] lpszUsername: A pointer to a null-terminated string that specifies the name of the user. This is the name of the user account to log on to .
	//    1) [in] lpszDomain: A pointer to a null-terminated string that specifies the name of the domain or server whose account database contains the lpszUsername account .
	//    2) [in] lpszPassword: A pointer to a null-terminated string that specifies the plaintext password for the user account specified by lpszUsername .
	//    3) [in] lpApplicationName: The name of the module to be executed .
	//    4) [in] lpCommandLine: The command line to be executed .
	//    5) [in] lpWorkingDir: The full path to the current directory for the process .
	//    6) [in] bShowWindow: Hides or show the GUI window .
	//	  ...
	// Returned value:
	//    Error Code.
	WINDOWSAPI_API int runAsForNT5InteractiveService(LPWSTR lpszUsername, LPWSTR lpszDomain, LPWSTR lpszPassword, LPCWSTR lpApplicationName, LPWSTR lpCommandLine, LPCWSTR lpWorkingDir, bool bShowWindow);


	// Functionality:
	//    Start a interactive process in another user's session. Only for desktop application .
	// Parameters:
	//    0) [in] lpszUsername: A pointer to a null-terminated string that specifies the name of the user. This is the name of the user account to log on to .
	//    1) [in] lpszDomain: A pointer to a null-terminated string that specifies the name of the domain or server whose account database contains the lpszUsername account .
	//    2) [in] lpszPassword: A pointer to a null-terminated string that specifies the plaintext password for the user account specified by lpszUsername .
	//    3) [in] lpApplicationName: The name of the module to be executed .
	//    4) [in] lpCommandLine: The command line to be executed .
	//    5) [in] lpWorkingDir: The full path to the current directory for the process .
	//    6) [in] bShowWindow: Hides or show the GUI window .
	//    7) [in] bWait: If wait for the process to exit .
	//    8) [in] dwMilliseconds: Milliseconds to wait for .
	//	  ...
	// Returned value:
	//    Error Code.
	WINDOWSAPI_API int runAsForDesktopApplication(LPWSTR lpszUsername, LPWSTR lpszDomain, LPWSTR lpszPassword, LPCWSTR lpApplicationName, LPWSTR lpCommandLine, LPCWSTR lpWorkingDir, bool bShowWindow = true, bool bWait = false, DWORD dwMilliseconds = 0);





	WINDOWSAPI_API BOOL ObtainSid(
		HANDLE hToken,           // Handle to an process access token.
		PSID   *psid             // ptr to the buffer of the logon sid
		);

	WINDOWSAPI_API void RemoveSid(
		PSID *psid               // ptr to the buffer of the logon sid
		);

	WINDOWSAPI_API BOOL AddTheAceWindowStation(
		HWINSTA hwinsta,         // handle to a windowstation
		PSID    psid             // logon sid of the process
		);

	WINDOWSAPI_API  BOOL AddTheAceDesktop(
		HDESK hdesk,             // handle to a desktop
		PSID  psid               // logon sid of the process
		);










#ifdef __cplusplus
}
#endif

#endif //__RUNAS_H__