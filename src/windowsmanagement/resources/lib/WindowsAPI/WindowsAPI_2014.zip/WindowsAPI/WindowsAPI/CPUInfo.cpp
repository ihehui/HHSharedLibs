
#include "stdafx.h"
#include <stdio.h>

#include "CPUInfo.h"



void getcpuidex(unsigned int CPUInfo[4], unsigned int InfoType, unsigned int ECXValue)
{
#if defined(__GNUC__)    // GCC
    __cpuid_count(InfoType, ECXValue, CPUInfo[0],CPUInfo[1],CPUInfo[2],CPUInfo[3]);
#elif defined(_MSC_VER)    // MSVC
    #if defined(_WIN64) || _MSC_VER>=1600    // 64λ�²�֧���������. 1600: VS2010, ��˵VC2008 SP1֮���֧��__cpuidex.
        __cpuidex((int*)(void*)CPUInfo, (int)InfoType, (int)ECXValue);
    #else
        if (NULL==CPUInfo)    return;
        _asm{
            // load. ��ȡ�������Ĵ���.
            mov edi, CPUInfo;    // ׼����ediѰַCPUInfo
            mov eax, InfoType;
            mov ecx, ECXValue;
            // CPUID
            cpuid;
            // save. ���Ĵ������浽CPUInfo
            mov    [edi], eax;
            mov    [edi+4], ebx;
            mov    [edi+8], ecx;
            mov    [edi+12], edx;
        }
    #endif
#endif    // #if defined(__GNUC__)
}

void getcpuid(unsigned int CPUInfo[4], unsigned int InfoType)
{
#if defined(__GNUC__)    // GCC
    __cpuid(InfoType, CPUInfo[0],CPUInfo[1],CPUInfo[2],CPUInfo[3]);
#elif defined(_MSC_VER)    // MSVC
    #if _MSC_VER>=1400    // VC2005��֧��__cpuid
        __cpuid((int*)(void*)CPUInfo, (int)InfoType);
    #else
        getcpuidex(CPUInfo, InfoType, 0);
    #endif
#endif    // #if defined(__GNUC__)
}

// ȡ��CPU���̣�Vendor��.
//
// result: �ɹ�ʱ�����ַ����ĳ��ȣ�һ��Ϊ12����ʧ��ʱ����0.
// pvendor: ���ճ�����Ϣ���ַ���������������Ϊ13�ֽ�.
int cpu_getVendor(char* pvendor)
{
    unsigned int dwBuf[4];
    if (NULL==pvendor)    return 0;
    // Function 0: Vendor-ID and Largest Standard Function
    getcpuid(dwBuf, 0);
    // save. ���浽pvendor
    *(unsigned int *)&pvendor[0] = dwBuf[1];    // ebx: ǰ�ĸ��ַ�.
    *(unsigned int *)&pvendor[4] = dwBuf[3];    // edx: �м��ĸ��ַ�.
    *(unsigned int *)&pvendor[8] = dwBuf[2];    // ecx: ����ĸ��ַ�.
    pvendor[12] = '\0';
    return 12;
}

// ȡ��CPU�̱꣨Brand��.
//
// result: �ɹ�ʱ�����ַ����ĳ��ȣ�һ��Ϊ48����ʧ��ʱ����0.
// pbrand: �����̱���Ϣ���ַ���������������Ϊ49�ֽ�.
int cpu_getName(char* pbrand)
{
    unsigned int dwBuf[4];
    if (NULL==pbrand)    return 0;
    // Function 0x80000000: Largest Extended Function Number
    getcpuid(dwBuf, 0x80000000U);
    if (dwBuf[0] < 0x80000004U)    return 0;
    // Function 80000002h,80000003h,80000004h: Processor Brand String
    getcpuid((unsigned int *)&pbrand[0], 0x80000002U);    // ǰ16���ַ�.
    getcpuid((unsigned int *)&pbrand[16], 0x80000003U);    // �м�16���ַ�.
    getcpuid((unsigned int *)&pbrand[32], 0x80000004U);    // ���16���ַ�.
    pbrand[48] = '\0';
    return 48;
}

void cpu_getPSN(char *pPSN)
{
    unsigned int varEAX, varEBX, varECX, varEDX;
    char str[256];

    //%eax=1 gives most significant 32 bits in eax
#if defined(__GNUC__)    // GCC
    __asm__ __volatile__ ("cpuid"   : "=a" (varEAX), "=b" (varEBX), "=c" (varECX), "=d" (varEDX) : "a" (1));
#elif defined(_MSC_VER)    // MSVC
    __asm
    {
        mov   eax,01h
        xor   edx,edx
        cpuid
        mov   varEDX,edx
        mov   varEAX,eax
    }
#endif    // #if defined(__GNUC__)
    sprintf(str, "%08X%08X", varEDX, varEAX); //i.e. XXXX-XXXX-xxxx-xxxx-xxxx-xxxx
    sprintf(pPSN, "%s", str);

    //sprintf(str, "%08X", varEDX); //i.e. XXXX-XXXX-xxxx-xxxx-xxxx-xxxx
    //sprintf(pPSN, "%C%C%C%C-%C%C%C%C", str[0], str[1], str[2], str[3], str[4], str[5], str[6], str[7]);
    //sprintf(str, "%08X", varEAX); //i.e. XXXX-XXXX-xxxx-xxxx-xxxx-xxxx
    //sprintf(pPSN, "%s-%C%C%C%C-%C%C%C%C", pPSN, str[0], str[1], str[2], str[3], str[4], str[5], str[6], str[7]);


    //%eax=3 gives least significant 64 bits in edx and ecx [if PN is enabled]
#if defined(__GNUC__)    // GCC
    __asm__ __volatile__ ("cpuid"   : "=a" (varEAX), "=b" (varEBX), "=c" (varECX), "=d" (varEDX) : "a" (3));
#elif defined(_MSC_VER)    // MSVC
    __asm
    {
        mov   eax,03h
        xor   ecx,ecx
        xor   edx,edx
        cpuid
        mov   varEDX,edx
        mov   varECX,ecx
    }
#endif    // #if defined(__GNUC__)
    sprintf(str, "%08X%08X", varEDX, varECX); //i.e. xxxx-xxxx-XXXX-XXXX-xxxx-xxxx
    if(strcmp("0000000000000000", str)){
        //�����ȫΪ0����Ҫ���ƿ���
        //strcat(pPSN, str);
        sprintf(pPSN, "%s%s", pPSN, str);
    }

    //sprintf(str, "%08X", varEDX); //i.e. xxxx-xxxx-xxxx-xxxx-XXXX-XXXX
    //sprintf(PSN, "%s-%C%C%C%C-%C%C%C%C", pPSN, str[0], str[1], str[2], str[3], str[4], str[5], str[6], str[7]);
    //sprintf(str, "%08X", varECX); //i.e. xxxx-xxxx-xxxx-xxxx-XXXX-XXXX
    //sprintf(PSN, "%s-%C%C%C%C-%C%C%C%C", pPSN, str[0], str[1], str[2], str[3], str[4], str[5], str[6], str[7]);


}

