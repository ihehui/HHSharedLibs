
#ifndef __HDINFO_H__
#define __HDINFO_H__


//http://blog.163.com/jinfd@126/blog/static/6233227720133218314327/


#include "lib.h"



#ifdef __cplusplus
extern "C"
{
#endif


	void ToLittleEndian(PUSHORT pWords, int nFirstIndex, int nLastIndex, char* pBuf);

	void TrimStart(char* pBuf);

	char *ConvertToString (DWORD diskdata [256], int firstIndex, int lastIndex, char* buf);

	//ȡ������Ӳ���ͺź����к�
	WINDOWSAPI_API BOOL GetPhysicDriveSerialNumber(char* pModelNo, char* pSerialNo, unsigned int driveIndex = 0);







#ifdef __cplusplus
}
#endif

#endif //__HDINFO_H__